<!DOCTYPE html>
<html>
<head>
	<title>Membuat CRUD</title>
	<title>Membuat CRUD</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

</head>
<body>
<div class="collapse" id="navbarToggleExternalContent">
  <div class="bg-dark p-4">
    <h5 class="text-white h4">Collapsed content</h5>
    <span class="text-muted">Toggleable via the navbar brand.</span>
  </div>
</div>
<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</nav>
</br>
<div class="container">
<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-pills card-header-pills">
      <li class="nav-item">
      <a class="nav-link active" href="\codeigniter">Back  To Home</a>
      </li>
    </ul>
  </div>
  <div class="card-body">
  <form action="<?php echo base_url(). 'crud/tambah_aksi'; ?>" method="post">
  <table class="table table-bordered table-stripped">
			<tr>
				<td>Nama</td>
				<td><input type="text" name="nama" class="form-control" value="<?= $this->input->post('nama'); ?>"></td>
			</tr>
			<tr>
           <td><label>kelas</label></td><td>
         <select name="kelas" class="form-control">
             <option value="">-- PILIH SALAH SATU --</option>
             <option value="X" <?= !empty($this->input->post('kelas') AND $this->input->post('kelas') == 'X' ? 'selected' : '' );?> >X</option>
             <option value="XI" <?= !empty($this->input->post('kelas') AND $this->input->post('kelas') == 'XI' ? 'selected' : '' );?>>XI</option>
             <option value="XII" <?= !empty($this->input->post('kelas') AND $this->input->post('kelas') == 'XII' ? 'selected' : '' );?>>XII</option>
        </select>
    
  </div>
</td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td><input type="text" name="alamat" class="form-control" value="<?= $this->input->post('alamat'); ?>"></td>
				<td><button type="submit" class="btn btn-primary">Kirim</td>
			</tr>
		</table>
	</form>	
  </div>
</div>
</body>
</html>