<!DOCTYPE html>
<html>
<head>
	<title>Membuat CRUD</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

</head>
<body>
<div class="collapse" id="navbarToggleExternalContent">
  <div class="bg-dark p-4">
    <h5 class="text-white h4">Collapsed content</h5>
    <span class="text-muted">Toggleable via the navbar brand.</span>
  </div>
</div>
<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</nav>
</br>
<div class="container">
<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-pills card-header-pills">
      <li class="nav-item">
        <span><a href="<?= base_url('crud/tambah'); ?>" style="float:right" class="btn btn-primary">Tambah Data</a></span>
      </li>
    </ul>
  </div>
  <div class="card-body">
  <table class="table table-bordered table-hover table-stripped">
        <thead>
		<tr>
			<th>ID</th>
			<th>Nama</th>
			<th>Kelas</th>
            <th>Alamat</th>
            <th>Opsi</th>
		</tr>
</thead>
<tbody>
        <?php 
		$no = 1;
		foreach($user as $u){ 
		?>
        <tr>
        <td><?php echo $no++ ?></td>
        <td><?php echo $u->nama ?></td>
        <td><?php echo $u->kelas ?></td>
        <td><?php echo $u->alamat ?></td>
        <td>
			      <button class="btn btn-warning"><?php echo anchor('crud/edit/'.$u->id,'Edit'); ?></button>
                  <button class="btn btn-danger"><?php echo anchor('crud/hapus/'.$u->id,'Hapus'); ?></button>
			</td>
        </tr>
        <?php } ?>
        </tbody>
        </table>
  </div>
</div>
</div>
        </body>
        </html>