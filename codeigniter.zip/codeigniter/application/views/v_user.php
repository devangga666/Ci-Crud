<html>
<head>
	<title>Menghubungkan codeigniter dengan database mysql</title>
</head>
<body>
	<h1>Mengenal Model Pada Codeigniter | MalasNgoding.com</h1>
	<table border="1">
		<tr>
			<th>ID</th>
			<th>Nama</th>
			<th>Kelas</th>
            <th>Alamat</th>
		</tr>
        <tr>
        <td><?php echo $user->nama ?></td>
        <td><?php echo $user->kelas ?></td>
        <td><?php echo $user->alamat ?></td>
        </tr>
        <?php } ?>
        </table>
        </body>
        </html>