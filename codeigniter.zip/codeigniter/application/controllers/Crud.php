<?php
    class Crud extends CI_Controller{
        function __construct(){
            parent::__construct();
            $this->load->model('M_data');

        }
        function index(){
            $data['user'] = $this->M_data->tampil_data()->result();
            $this->load->view('V_tampil',$data);
            $this->load->helper('url');
        }
        function tambah(){
            $this->load->view('V_input');
        }
     
        function tambah_aksi(){
            $nama = $this->input->post('nama');
            $kelas = $this->input->post('kelas');
            $alamat = $this->input->post('alamat');
     
            $data = array(
                'nama' => $nama,
                'kelas' => $kelas,
                'alamat' => $alamat
            );
            $this->M_data->input_data($data,'user');
            redirect('crud/');
        }
        function hapus($id){
            $where = array('id' => $id);
            $this->M_data->hapus_data($where,'user');
            redirect('crud/');
        }
        function edit($id){
            $where = array('id' => $id);
            $data['user'] = $this->M_data->edit_data($where,'user')->result();
            $this->load->view('V_edit',$data);
        }
        function update(){
             $id = $this->input->post('id');
             $nama = $this->input->post('nama');
             $kelas = $this->input->post('kelas');
             $alamat = $this->input->post('alamat');

             $where = array(
                'id' => $id 
            );
             $data = array (
                 'nama' => $nama,
                 'kelas' => $kelas,
                 'alamat' => $alamat
             );
             $this->M_data->update_data($where,'user',$data);
             redirect('crud/');
    }
}